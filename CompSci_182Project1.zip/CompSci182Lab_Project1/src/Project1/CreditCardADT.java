package Project1;
import java.util.Arrays;

/**
 *
 * @author Christian Hernandez
 * Date 9/22/2020
 */
public class CreditCardADT {
    //Global variables
    private String customerName;
    private int[] accNum = new int[16];
    private String nextDueDate;
    private double rewardPoints;
    private double availableBalance;
    private double accountBalance;
    
    // Default constructor
    public CreditCardADT() {
        customerName = "";
        createAccNum();
        nextDueDate = "October 25th, 2020";
        rewardPoints = 0;
        availableBalance = 500;
        accountBalance = 0;
        
        
    }
    // Parameter based constructors
    public CreditCardADT(String newCM) {
        setCustomerName(newCM);
        createAccNum();
        nextDueDate = "";
        rewardPoints = 0;
        availableBalance = 500;
        accountBalance = 0;
    }
    
    
    public CreditCardADT(String newCM, String newDD) {
        setCustomerName(newCM);
        createAccNum();
        setNextDueDate(newDD);
        rewardPoints = 0;
        availableBalance = 500;
        accountBalance = 0;
    }
    
    public CreditCardADT(String newCM, String newDD, int newRP) {
        setCustomerName(newCM);
        createAccNum();
        setNextDueDate(newDD);
        setRewardPoints(newRP);
        availableBalance = 500;
        accountBalance = 0;
    }
    
    public CreditCardADT(String newCM, String newDD, int newRP, double newAB) {
        setCustomerName(newCM);
        createAccNum();
        setNextDueDate(newDD);
        setRewardPoints(newRP);
        setAccountBalance(newAB);
        accountBalance = 0;
    }
    
    public CreditCardADT(String newCM, String newDD, int newRP, double newAVB, double newAB) {
        setCustomerName(newCM);
        createAccNum();
        setNextDueDate(newDD);
        setRewardPoints(newRP);
        setAvailableBalance(newAVB);
        setAccountBalance(newAB);
    }
    // Get and Set methods
    public String getCustomerName() {
        return customerName;
    }
    
    public void getAccountNumber() {
        for (int i = 0; i < accNum.length; i++) {
            System.out.print(accNum[i]);
        }
        System.out.println("");
    }
    
    public String getNextDueDate() {
        return nextDueDate;
    }
    
    public double getRewardPoints() {
        return rewardPoints;
    }
    
    public double getAvailableBalance() {
        return availableBalance;
    }
    
    public double getAccountBalance() {
        return accountBalance;
    }

    public void setCustomerName(String newCN) {
        customerName =  newCN;
    }
    
    public void createAccNum() {
        for (int i = 0; i < accNum.length; i++) {
            accNum[i] = (int)(Math.random() * 10);
        }
    }
    
    public void setNextDueDate(String newDD) {
        nextDueDate =  newDD;
    }
    
    public void setRewardPoints(double newRP) {
        if (newRP > 0) {
            rewardPoints =  newRP;
        } else {
            System.out.println("Error cannot add negative reward points");
        }
    }
    
    public void setAvailableBalance(double newAVB) {
        if (newAVB < 500) {
            availableBalance = newAVB;
        } else {
            availableBalance = 500;
        }
    }
    
    public void setAccountBalance(double newAB) {
        accountBalance =  newAB;
    }
    // ADT Client methods
    public void creditCardCharge(double charge) {
        if (charge < availableBalance) {
            setAccountBalance(accountBalance + charge);
            setAvailableBalance(availableBalance - charge);
            setRewardPoints(rewardPoints + (charge*10));
            System.out.println("Purchase of $" + charge);
        } else {
            System.out.println("That purchase is greater than available balance.");
        }
    }
    
    public double cashAdvance(double ca) {
        setAccountBalance(accountBalance + ca);
        setAvailableBalance(availableBalance - ca);
        addInterest(8);
        return accountBalance;
    }
    
    public void payment(double pay) {
        if (accountBalance != 0) {
            setAccountBalance(accountBalance - pay);
            setAvailableBalance(availableBalance + pay);
        }
    }
    
    public void addInterest(double interest) {
        if (interest > 0) {
            setAccountBalance((accountBalance + (accountBalance * interest/100)));
        } else {
            System.out.println("Error cannot add negative interest");
        }
    }
    
    public void displayStats() {
        System.out.println("Customer Name: " + getCustomerName());
        System.out.print("Account Number: ");
        getAccountNumber();
        System.out.println("Next Due Date: " + getNextDueDate());
        System.out.println("Reward Points: " + getRewardPoints());
        System.out.println("Available Balance: $" + getAvailableBalance());
        System.out.println("Account Balance: $" + getAccountBalance());
    }
    
}
