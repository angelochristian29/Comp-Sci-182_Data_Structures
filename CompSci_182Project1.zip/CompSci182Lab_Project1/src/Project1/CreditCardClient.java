package Project1;
import java.util.Scanner;

/**
 *
 * @author Christian Hernandez
 */
public class CreditCardClient {

    public static void main(String[] args) {
        String choiceCC;
        CreditCardADT cc = new CreditCardADT();
        Scanner myScanner = new Scanner(System.in);
        //setup
        System.out.println("Setup your account");
        System.out.print("Please enter your name: ");
        cc.setCustomerName(myScanner.nextLine());
        System.out.println("");
        //Wall of methods
        System.out.println("To make a credit card charge type 'credit card charge'");
        System.out.println("To ask for a cash advance type 'cash advance'");
        System.out.println("To make a payment type 'payment'");
        System.out.println("To add interest type 'add interest'");
        System.out.println("To see your account stats type 'display stats'");
        System.out.println("To exit program type 'quit'");
        System.out.println("");
        System.out.print("Type an option here: ");
        choiceCC = myScanner.nextLine();
        System.out.println("");
        //Menu loop
        while (!(choiceCC.equalsIgnoreCase("quit"))) {
            switch (choiceCC) {
                case "credit card charge":
                    cc.creditCardCharge((int) (1 + (Math.random() * 10)));
                    break;
                case "cash advance":
                    System.out.print("Input amount of cash to advance: ");
                    cc.cashAdvance(myScanner.nextDouble());
                    break;
                case "payment":
                    System.out.print("Input amount you want to pay: ");
                    cc.payment(myScanner.nextDouble());
                    break;
                case "add interest":
                    System.out.print("Input percent of interest to add: ");
                    cc.addInterest(myScanner.nextInt());
                    break;
                case "display stats":
                    cc.displayStats();
                    break;
                case "quit":
                    break;
                default:
                    break;
            }
            System.out.println("");
            System.out.print("Type another option here: ");
            choiceCC = myScanner.nextLine();
            System.out.println("");
        }
        System.out.println("Have a nice day!");
    }
    
}
