package Project1;

/**
 *
 * @author Christian Hernandez
 */
public class ExponentialRecursive {

    public static void main(String[] args) {
        int base = 2;
        for (int j = 0; j <= 10; j++) {
            System.out.println("2.0^" + j + " = " + power1(base, j) + " computed iteratively.");
            System.out.println("2.0^" + j + " = " + power2(base, j) + " computed recursively.");
        }
    }
    
    public static double power1(int x, int n) {
        int answer = 1;
        for (int i = 1; i <= n; i++) {
                answer = answer * x;
        }
        return answer;
    }
    public static double power2(int x, int n) {
        if (n == 0) {
            return 1;
        } else if (n > 0) {
            return x * power2(x, n-1);
        }
        return 0;
    }
}
