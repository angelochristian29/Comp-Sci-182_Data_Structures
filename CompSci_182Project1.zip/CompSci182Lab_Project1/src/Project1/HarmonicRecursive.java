package Project1;
import java.util.Scanner;
/**
 *
 * @author Christian Hernandez
 */
public class HarmonicRecursive {
    
    public static void main(String[] args) {
        int userCap;
        Scanner myScanner = new Scanner(System.in);
        System.out.print("Enter a number and I will determine its harmonic sum: ");
        userCap = myScanner.nextInt();
        System.out.println("The harmonic sum of " + userCap + " is " + harmonicSum(userCap, 1.0));
        
    }
    
    public static double harmonicSum(int end,double n) {
        if (n == end) {
            return 1/n;
        } else {
            return 1/n + harmonicSum(end, (n+1));
        }
    }
}
