package Project2;

/**
 * Project 2
 * Source code file: LinkedString.java
 * @author Christian Hernandez
 * Due 10/6
 * Description: creates a java string class
 * 
 */

public class LinkedString {
    //declare the class data fields
    private Node head;
    private int length;
    
    //Initializers
    public LinkedString() {
        head = null;
        length = 0;
    } 
    
    public LinkedString(char[] value) {
        //Creates new Linked List with char array
        Node curr;
        Node newNode = new Node(value[0]);
        head = newNode;
        curr = head;
        for (int i = 1; i < value.length; i++) {
            newNode = new Node(value[i]);
            curr.setNext(newNode);
            curr = newNode;
        }
        curr.setNext(null);
        length = value.length;
    }
    public LinkedString(String original) {
        //Creates new Linked List with string
        Node curr;
        Node newNode = new Node(original.charAt(0));
        head = newNode;
        curr = head;
        for(int i = 1; i < original.length(); i++) {
            newNode = new Node(original.charAt(i));
            curr.setNext(newNode);
            curr = newNode;
        }
        length = original.length();
    }
    
    //ADT methods
    public LinkedString concat(LinkedString str) {
        if (head == null) {
            head = str.head;
        } else {
            Node curr = head;
            while (curr.getNext() != null) {
                curr = curr.getNext();
            }
            curr.setNext(str.head);
            length = length + str.length;
        }
        return str;
    }
    public LinkedString replace(char oldChar, char newChar) {
        //Replaces one character in list with another based on argument
        Node curr;
        for (curr = head; curr != null; curr = curr.getNext()) {
            if (curr.getItem() == oldChar) {
                curr.setItem(newChar);
            }
        }
        return null;
    }
    public char charAt(int index) {
        //Returns specified item in linked list
        Node curr;
        curr = head;
        int j = index;
        
        if (index == 0) {
            return curr.getItem();
        } else if (j > 0 && j < length) {
            for (int i = 0; i < index; i++) {
                curr = curr.getNext();
            }
        } else {
            return 0;
        }
        return curr.getItem();
    }
    public boolean isEmpty() {
        //Checks to see if linked list length is 0
        if (length == 0) {
            return true;
        } else {
            return false;
        }
    }
    
    public int length() {
        return length;
    }
    
    @Override
    public String toString() {
        Node curr;
        if (head == null) {
            return "[]";
        } else {
            String toStr = "";
            for (curr = head; curr != null; curr = curr.getNext()) {
                toStr += curr.getItem();
            }
            return toStr;
        }
    }
}
