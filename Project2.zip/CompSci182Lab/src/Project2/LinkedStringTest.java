package Project2;
import java.util.Scanner;

/**
 * Project 2
 * Source code file: LinkedString.java
 * @author Christian Hernandez
 * Due 10/6
 * Description: creates a java string class
 */
public class LinkedStringTest {

    public static void main(String[] args) {
        Scanner myScan = new Scanner(System.in);
        String choiceLS;
        String charString;
        String strLS;
        System.out.print("Type a string to use for the linked list using a char array here: ");
        charString = myScan.nextLine();
        char[] charArr1 = charString.toCharArray();
        LinkedString message1 = new LinkedString(charArr1);
        System.out.println("");
        System.out.print("Type a string to use for the linked list using a string here: ");
        strLS = myScan.nextLine();
        LinkedString message2 = new LinkedString(strLS);
        
        System.out.println("To make a new list type: 'new list'");
        System.out.println("To concat lists type: 'concat'");
        System.out.println("To replace a letter in a list type: 'replace'");
        System.out.println("To find a letter at a certain index type: 'charAt'");
        System.out.println("To check if a list is empty type: 'check if empty'");
        System.out.println("To check the length of a list type: length");
        System.out.println("To print a list type: print list");
        System.out.println("To end the program type: quit");
        System.out.print("Type an option here: ");
        choiceLS = myScan.nextLine();
        
        while (!(choiceLS.equalsIgnoreCase("quit"))) {
            switch (choiceLS) {
                case "concat":
                    message1.concat(message2);
                    System.out.println("New merged List: " + message1.toString());
                    break;
                case "replace":
                    char userOldChar;
                    char userNewChar;
                    System.out.println("Which list do you want to replace a letter?");
                    System.out.print("Type 1 or 2 here: ");
                    choiceLS = myScan.nextLine();
                    if (choiceLS.equalsIgnoreCase("1")) {
                        System.out.print("Type out the old character you want to replace here: ");
                        choiceLS = myScan.nextLine();
                        userOldChar = choiceLS.charAt(0);
                        System.out.print("Type out the new character you want to put in here: ");
                        choiceLS = myScan.nextLine();
                        userNewChar = choiceLS.charAt(0);
                        message1.replace(userOldChar, userNewChar);
                        System.out.println("New list: " + message1.toString());
                    } else if (choiceLS.equalsIgnoreCase("2")) {
                        System.out.print("Type out the old character you want to replace here: ");
                        choiceLS = myScan.nextLine();
                        userOldChar = choiceLS.charAt(0);
                        System.out.print("Type out the new character you want to put in here: ");
                        choiceLS = myScan.nextLine();
                        userNewChar = choiceLS.charAt(0);
                        message2.replace(userOldChar, userNewChar);
                        System.out.println("New list: " + message2.toString());
                    }
                    
                    break;
                case "charAt":
                    int userIndex;
                    System.out.println("Which list do you want to find a letter?");
                    System.out.print("Type 1 or 2 here: ");
                    choiceLS = myScan.nextLine();
                    if (choiceLS.equalsIgnoreCase("1")) {
                        System.out.print("Type out the index of the character you want returned: ");
                        choiceLS = myScan.nextLine();
                        userIndex = Integer.parseInt(choiceLS);
                        System.out.println("The character at the index is: " + message1.charAt(userIndex));
                    } else if (choiceLS.equalsIgnoreCase("2")) {
                        System.out.print("Type out the index of the character you want returned: ");
                        choiceLS = myScan.nextLine();
                        userIndex = Integer.parseInt(choiceLS);
                        System.out.println("The character at the index is: " + message2.charAt(userIndex));
                    }
                    break;
                case "check if empty":
                    System.out.println("Which list do you want to check? ");
                    System.out.print("Type out 1 or 2: ");
                    choiceLS = myScan.nextLine();
                    if (choiceLS.equalsIgnoreCase("1")) {
                        System.out.println("True or false: The list is empty? ");
                        System.out.println(message1.isEmpty());
                    } else if (choiceLS.equalsIgnoreCase("2")) {
                        System.out.println("True or false: The list is empty? ");
                        System.out.println(message2.isEmpty());
                    }
                    break;
                case "length":
                    System.out.println("Which list do you want to find the length of?");
                    System.out.print("Type out 1 or 2: ");
                    choiceLS = myScan.nextLine();
                    if (choiceLS.equalsIgnoreCase("1")) {
                        System.out.println("The length of list 1 is: " + message1.length());
                    } else if (choiceLS.equalsIgnoreCase("2")) {
                        System.out.println("The length of list 1 is: " + message2.length());
                    }
                    break;
                case "print list":
                    System.out.println("Which list do you want print?");
                    System.out.print("Type out 1 or 2: ");
                    choiceLS = myScan.nextLine();
                    if (choiceLS.equalsIgnoreCase("1")) {
                        System.out.println("List 1 is: " + message1.toString());
                    } else if (choiceLS.equalsIgnoreCase("2")) {
                        System.out.println("List 1 is: " + message2.toString());
                    }
                    break;
                case "quit":
                    break;
                default:
                    break;
            }
            System.out.println("");
            System.out.print("Type another option here: ");
            choiceLS = myScan.nextLine();
            System.out.println("");
        }
        
    }
    
    
}
