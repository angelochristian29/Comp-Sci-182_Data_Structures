package Project3.phase1;

/**
 *
 * @author Christian
 */
public class StackException extends java.lang.RuntimeException {
    public StackException(String s) {
        super(s);
    }
}
