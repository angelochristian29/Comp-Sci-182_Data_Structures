package Project3.phase2;

/**
 *
 * @author Christian Hernandez
 */
public class StackException extends java.lang.RuntimeException {
    public StackException(String s) {
        super(s);
    }
}
