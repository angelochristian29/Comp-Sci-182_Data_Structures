package Project3.phase2;

import Project3.phase1.StackException;

/**
 *
 * @author Christian
 */
public interface StackInterface {
    public boolean isEmpty();
    
    public void popAll();
    
    public void push(char newItem) throws StackException;
    
    public char pop() throws StackException;
    
    public char peek() throws StackException;
}
