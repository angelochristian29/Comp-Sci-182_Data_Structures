package Project3.phase2;
import java.util.Scanner;

/**
 *
 * @author Christian Hernandez
 */
public class StringRecognizer {
    
    public static void main(String[] args) {
        String userLine;
        StackReferenceBased stack = new StackReferenceBased();
        Scanner myScan = new Scanner(System.in);
        System.out.println("Enter a string that follows the format: ");
        System.out.println("𝐿 = {𝑤$𝑤′:𝑤 is a possibly empty string of characters other than $, 𝑤′ = 𝑟𝑒𝑣𝑒𝑟𝑠e(𝑤)}");
        userLine = myScan.nextLine();
        char[] charArray = userLine.toCharArray();
        int i = 0;
        char ch = ' ';
        while (ch != '$') {
            stack.push(charArray[i]);
            i++;
            ch = charArray[i];
        }
        i++;
        
        boolean inLanguage = true;
        while (inLanguage && i < charArray.length) {
            ch = charArray[i];
            try {
                char stackTop = stack.pop();
                if (stackTop == ch) {
                    i++;
                } else {
                    inLanguage = false;
                }
            } catch (StackException e){
                inLanguage = false;
            }
        }
        
        if (inLanguage && stack.isEmpty()) {
            System.out.println("User-given string is in Language");
        } else {
            System.out.println("User-given string is not in Language");
        }
    }
}
