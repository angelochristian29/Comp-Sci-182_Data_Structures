package Project4;

/**
 * Project 4
 * Source code file: ADTQueue.java
 * @author Christian Hernandez
 * Due 11/10
 * Description: creates a java queue ADT
 */
public class ADTQueue implements QueueInterface {
    private Node head;
    private Node tail;
    
    //default constructor
    public ADTQueue() {
        head = null;
        tail = null;
    }
    //determines whether or not list is empty
    public boolean isEmpty() {
        return tail == null;
    }
    //Adds new node to the end of the list
    public void enqueue(char newItem) {
        Node newNode = new Node(newItem);
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            tail.setNext(newNode);
            tail = newNode;
        }
    }
    //removes and returns first node from the list
    public char dequeue() throws QueueException {
        if (!isEmpty()) {
            Node temp = head;
            head = head.getNext();
            if (head == null) {
                tail = null;
            }
            return temp.getItem();
        } else {
            throw new QueueException("QueueException: " + "queue empty");
        }
    }
    
    //removes all nodes from list
    public void dequeueAll() {
        head = null;
        tail = null;
    }
    //returns first node in the list
    public char peek() throws QueueException {
        if (!isEmpty()) {
            return head.getItem();
        } else {
            throw new QueueException("QueueException: " + "queue empty");
        }
    }
    //prints full queue
    public String printQueue() throws QueueException{
        String queueFull = "";
        if (!isEmpty()) {
            Node curr;
            for (curr = head; curr != null; curr = curr.getNext()) {
                queueFull += curr.getItem();
            }
            return queueFull;
        } else {
            throw new QueueException("QueueException: " + "stack empty");
        }
    }
}
