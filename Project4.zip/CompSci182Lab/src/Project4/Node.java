package Project4;

/**
 * Project 4
 * Source code file: Node.java
 * @author Christian Hernandez
 * Due 11/10
 * Description: creates a java Node ADT
 */
public class Node {
    private char item;
    private Node next;
    
    public Node() {
        item = ' ';
        next = null;
    }
    public Node(char newItem) {
        setItem(newItem);
        next = null;
    }
    public Node(char newItem, Node newNext) {
        setItem(newItem);
        setNext(newNext);
    }
    public void setItem(char newItem) {
        item = newItem;
        
    }
    public void setNext(Node newNext) {
        if (newNext != null) {
            next = newNext;
        }
    }
    public char getItem() {
        return item;
    }
    public Node getNext() {
        return next;
    }
}
