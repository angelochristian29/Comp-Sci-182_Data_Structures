package Project4;

/**
 *
 * @author Christian
 */
public class QueueException extends java.lang.RuntimeException {
    public QueueException(String s) {
        super(s);
    }
}