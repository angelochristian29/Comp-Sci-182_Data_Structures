package Project4;

/**
 * Project 4
 * Source code file: QueueInterface.java
 * @author Christian Hernandez
 * Due 11/10
 * Description: creates a java queue ADT
 */
public interface QueueInterface {
    public boolean isEmpty();
    
    public void enqueue(char newItem);
    
    public char dequeue() throws QueueException;
    
    public void dequeueAll();
    
    public char peek() throws QueueException;
    
    public String printQueue();
}
