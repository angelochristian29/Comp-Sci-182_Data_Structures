package Project4;
import java.util.Scanner;

/**
 * Project 4
 * Source code file: QueueTest.java
 * @author Christian Hernandez
 * Due 11/10
 * Description: creates a java queue ADT test class
 */
public class QueueTest {

    public static void main(String[] args) {
        ADTQueue q = new ADTQueue();
        Scanner myScan = new Scanner(System.in);
        String choice = "";
        
        System.out.println("To check if the queue is empty, type: 'empty'");
        System.out.println("To enqueue a char, type: 'enqueue char'");
        System.out.println("To enqueue a string, type: 'enqueue string'");
        System.out.println("To dequeue an item, type: 'dequeue'");
        System.out.println("To peek at the queue, type: 'peek'");
        System.out.println("To dequeue the whole queue, type: 'dequeue all'");
        System.out.println("To end the program type: quit");
        System.out.println("");
        System.out.print("Type an option here: ");
        choice = myScan.nextLine();
        while (!(choice.equalsIgnoreCase("quit"))) {
            switch(choice) {
                case "empty":
                    System.out.println("Is the queue empty? " + q.isEmpty());
                    break;
                case "enqueue string":
                    String userLine;
                    System.out.print("Type in a string to enqueue here: ");
                    userLine = myScan.nextLine();
                    for (int i = 0; i < userLine.length(); i++) {
                        q.enqueue(userLine.charAt(i));
                    }
                    break;
                case "enqueue char":
                    String userChar;
                    System.out.print("Type in a character to enqueue here: ");
                    userChar = myScan.nextLine();
                    q.enqueue(userChar.charAt(0));
                    break;
                case "dequeue":
                    try {
                        System.out.println("Item dequeued was: " + q.dequeue());
                    } catch (QueueException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "peek":
                    try {
                        System.out.println("The front of the queue is: " + q.peek());
                    } catch (QueueException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "dequeue all":
                    q.dequeueAll();
                    System.out.println("Queue was emptied");
                    break;
                case "print queue":
                    try {
                        System.out.println("The printed queue is: " + q.printQueue());
                    } catch (QueueException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "quit":
                    break;
                default:
                    System.out.println("Not a valid option");
                    break;
            }
            System.out.println("");
            System.out.print("Type another option here: ");
            choice = myScan.nextLine();
            System.out.println("");
        }
        
    }
    
}
