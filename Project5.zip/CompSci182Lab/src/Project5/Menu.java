package Project5;
import java.util.Scanner;
/**
 * Project 5
 * Source code file: Menu.java
 * @author Christian Hernandez
 * Due 12/10
 * Description: creates a class to represent a menu for the PhoneBook
 */
public class Menu {
    
    public static void main(String[] args) throws Exception {
        PhoneBook pb = new PhoneBook();
        Scanner myScan = new Scanner(System.in);
        String userName;
        String userNumber;
        String choice = "";
        
        System.out.println("To add a person to the phonebook, type: 'add'");
        System.out.println("To delete a person from the phonebook, type: 'delete'");
        System.out.println("To find a person, type: 'find'");
        System.out.println("To change a number in the Phonebook, type: 'change'");
        System.out.println("To view the phonebook, type: 'load'");
        System.out.println("To end the program and save the phonebook, type: quit");
        System.out.println("");
        System.out.print("Type an option here: ");
        choice = myScan.nextLine();
        while (!(choice.equalsIgnoreCase("quit"))) {
            switch(choice) {
                case "add":
                    System.out.print("Type out the name of the person you want to add here: ");
                    userName = myScan.nextLine();
                    System.out.print("Type out the phone number of the person you want to add here: ");
                    userNumber = myScan.nextLine();
                    pb.add(userName, userNumber);
                    break;
                case "delete":
                    System.out.print("Type out the name of the person you want to delete here: ");
                    userName = myScan.nextLine();
                    try {
                        pb.delete(pb.getRoot(), userName);
                    } catch (TreeException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "find":
                    System.out.print("Type out the name of the person you want to find here: ");
                    userName = myScan.nextLine();
                    System.out.println("The following is the info on the person.");
                    try {
                        System.out.println("Name : " + pb.find(userName).getName() 
                            + " Phone Number: " + pb.find(userName).getPhoneNumber());
                    } catch (TreeException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "change":
                    System.out.print("Type out the name of the person you want to change here: ");
                    userName = myScan.nextLine();
                    System.out.print("Type out the phone number of the person you want to change here: ");
                    userNumber = myScan.nextLine();
                    try {
                        pb.change(userName, userNumber);
                    } catch (TreeException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "quit":
                    break;
                default:
                    System.out.println("Not a valid option");
                    break;
                    
            }
            System.out.println("");
            System.out.print("Type another option here: ");
            choice = myScan.nextLine();
            System.out.println("");
        }
        pb.quit();
        System.out.println("");
        System.out.println("Have a great day!");
    }
    
}
