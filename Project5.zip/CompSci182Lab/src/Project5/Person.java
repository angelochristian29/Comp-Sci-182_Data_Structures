package Project5;

/**
 * Project 5
 * Source code file: Person.java
 * @author Christian Hernandez
 * Due 12/10
 * Description: creates a class to represent a person in the PhoneBook
 */
public class Person {
    
    private String name;
    private String phoneNumber;
    private Person leftChild;
    private Person rightChild;
    
    //Constructors
    public Person() {
        name = "";
        phoneNumber = "";
    }
    public Person(String newName) {
        setName(newName);
        phoneNumber = "";
        leftChild = null;
        rightChild = null;
    }
    public Person(String newName, String newPhoneNumber) {
        setName(newName);
        setPhoneNumber(newPhoneNumber);
        leftChild = null;
        rightChild = null;
    }
    public Person(String newName, String newPhoneNumber, Person newLeft) {
        setName(newName);
        setPhoneNumber(newPhoneNumber);
        setLeftChild(newLeft);
        rightChild = null;
    }
    public Person(String newName, String newPhoneNumber, Person newLeft, Person newRight) {
        setName(newName);
        setPhoneNumber(newPhoneNumber);
        setLeftChild(newLeft);
        setRightChild(newRight);
    }
    //Methods
    public String getName() throws TreeException {
        if (name.length() > 0) {
            return name;
        } else {
            throw new TreeException("TreeException: " + "slot empty");
        }
    }
    public String getPhoneNumber() throws TreeException {
        if (name.length() > 0) {
            return phoneNumber;
        } else {
            throw new TreeException("TreeException: " + "slot empty");
        }
    }
    public void setName(String newName) {
        if (newName.length() > 0) {
            name = newName;
        }
    }
    public void setPhoneNumber(String newPhoneNumber) {
        if (newPhoneNumber.length() > 0) {
            phoneNumber = newPhoneNumber;
        }
    }
    public Person getLeftChild() {
        return leftChild;
    } 
    public Person getRightChild() {
        return rightChild;
    }
    public void setLeftChild(Person newLeft) {
        leftChild = newLeft;
    }
    public void setRightChild(Person newRight) {
        rightChild = newRight;
    }
    
}
