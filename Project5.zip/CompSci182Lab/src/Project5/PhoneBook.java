package Project5;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Project 5
 * Source code file: PhoneBook.java
 * @author Christian Hernandez
 * Due 12/10
 * Description: creates a phone book as a binary search tree
 */
public class PhoneBook {
    private Person root;
    private List<String> PBList = new ArrayList<String>();
    private String fileName = "C:\\Users\\Public\\Documents\\PhoneBook.txt";
    private String line;
    private FileWriter filewriter;
    private BufferedWriter buffer;
    private File file;
    private FileReader filereader;
    private BufferedReader bufferedreader;
    
    //Constructors
    public PhoneBook() {
        root = null;
    }
    public PhoneBook(String name, String PN) {
        root = new Person(name, PN);
    } 
    public PhoneBook(Person p) {
        root = p;
    }
    //Methods
    public Person getRoot() {
        return root;
    }
    public void add(String name, String phoneNumber) {
        Person curr = new Person(name, phoneNumber);
        if (root == null) {
            root = curr;
        } else {
            add(root, curr);
        }
    }
    public void add(Person r, Person newNode) {
        int itemCompare = r.getName().compareToIgnoreCase(newNode.getName());
        if (itemCompare > 0 && r.getLeftChild() == null) {
            r.setLeftChild(newNode);
        }
        if (itemCompare > 0 && r.getLeftChild() != null) {
            add(r.getLeftChild(), newNode);
        }
        if (itemCompare < 0 && r.getRightChild() == null) {
            r.setRightChild(newNode);
        }
        if (itemCompare < 0 && r.getRightChild() != null) {
            add(r.getRightChild(), newNode);
        }
    }
    public void delete(String name) {
        root = delete(root, name);
    }
    public Person delete(Person r, String name) throws TreeException{
        if (r == null) {
            return r;
        }
        int itemCompare = r.getName().compareToIgnoreCase(name);
        if (itemCompare > 0) {
            r.setLeftChild(delete(r.getLeftChild(), name));
        } else if (itemCompare < 0) {
            r.setRightChild(delete(r.getRightChild(), name));
        } else {
            if (r.getLeftChild() == null) {
                return r.getRightChild();
            } else if (r.getRightChild() == null) {
                return r.getLeftChild();
            }
            r.setName(minVal(r.getRightChild()).getName());
            r.setPhoneNumber(minVal(r.getRightChild()).getPhoneNumber());
            r.setRightChild(delete(r.getRightChild(), r.getName()));
        }
        return r;
    }
    
    public Person find(String name) throws TreeException {
        Person curr = root;
        int itemCompare = curr.getName().compareTo(name);
        while (!(curr.getName().equalsIgnoreCase(name))) {
            if (itemCompare > 0) {
                curr = curr.getLeftChild();
            } else {
                curr = curr.getRightChild();
            }
            if (curr == null) {
                throw new TreeException("TreeException: " + "Name not found");
            }
        }
        return curr;
    }
    public void change(String name, String newPhoneNumber) {
        find(name).setPhoneNumber(newPhoneNumber);
    }
    public void saveToFile() throws Exception {
        file = new File(fileName);
        try (PrintWriter output = new PrintWriter(file)) {
            output.println("Here's what the Phonebook looks like");
            PBList.forEach((PBList1) -> {
                output.println(PBList1);
            });
        }
    }
    public void loadFile() throws Exception {
        if (file.exists()) {
            filereader = new FileReader(fileName);
            bufferedreader = new BufferedReader(filereader);
            while ((line = bufferedreader.readLine()) !=null) {
                System.out.println(line);
            }
        }
    }
    public void inOrder(Person r) {
        if (r != null) {
            if (r.getLeftChild() != null) {
                inOrder(r.getLeftChild());
            }
            PBList.add("Name: " + r.getName() + ", Phone Number: " + r.getPhoneNumber());
            if (r.getRightChild() != null) {
                inOrder(r.getRightChild());
            }
        }
    }
    public void quit() throws Exception {
        inOrder(root);
        saveToFile();
        loadFile();
    }
    public Person minVal(Person curr) {
        while (curr.getLeftChild() != null) {
            curr = curr.getLeftChild();
        }
        return curr;
    }
    
}
