package Project5;

/**
 * Project 5
 * Source code file: TreeException.java
 * @author Christian Hernandez
 * Due 12/10
 * Description: creates an exception class for the Binary Search Tree
 */
public class TreeException extends java.lang.RuntimeException {
    public TreeException(String s) {
        super(s);
    }
}
